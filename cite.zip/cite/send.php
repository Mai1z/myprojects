<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8"> 
	<link href="https://fonts.googleapis.com/css?family=Pacifico&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.css"/>
	<link rel="shortcut icon" href="assets/images/i1.jpg" type="image/png">
	<link rel="stylesheet" href="assets/css/style.css">
	<meta name="viewport" content="width=device-width">
	<title>Зарубежные сладости</title>

	<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>


</head>
<body>

<!-- Header -->

<header class="header" id="header">
	<div class="container">
		<div class="header_inner">
			<div class="header_logo">SweetBOX</div>
			<div class="logo">
				<img class="logo" src="assets/images/l1.jpg">
			</div>
			<nav class="nav">
				<a class="nav_link" href="#" data-scroll="#intro">Главная </a>
				<a class="nav_link" href="#"
				data-scroll="#goods">Цены</a>
				<a class="nav_link" href="#"
				data-scroll="#form">Заказ</a>
				<a class="nav_link" href="#"
				data-scroll="#footer">Контакты</a>
			</nav>
		</div>
	</div>	
</header>

<!-- Intro -->

<div class="intro" id="intro">
    <div class="container">
    	<div class="intro_inner">
    		<h2 class="intro_subtitle">Зарубежные сладости</h2>
    		<h1 class="intro_title">SweetBOX</h1>
    	</div>
	</div>
</div>

<!-- Slider -->

<div id="slider">
	<div class="slider1"></div>
	<div class="slider2"></div>
	<div class="slider3"></div>
</div>

<!-- Goods -->

<div class="goods">
	<div class="container">
		<div class="goods_inner" id="goods">
			<div class="goods_item">
				<img class="goods_icon" src="assets/images/g1.jpg" alt="">
				<h3 class="goods_title">Маленький бокс 990 руб.</h3>
				<div class="goods_text">(Маленькая коробочка содержит до 5 позиций редких сладостей!)</div>
			</div>
			<div class="goods_item">
				<img class="goods_icon" src="assets/images/g2.jpg" alt="">
				<h3 class="goods_title">Средний бокс 1990 руб.</h3>
				<div class="goods_text">(Средняя коробочка содержит до 10 позиций редких сладостей!)</div>
			</div>
			<div class="goods_item">
				<img class="goods_icon" src="assets/images/g3.jpg" alt="">
				<h3 class="goods_title">Большой бокс 2990 руб.</h3>
				<div class="goods_text">(Большая коробочка содержит до 5 позиций редких сладостей!)</div>
			</div>

<!-- Zakaz Form -->

		</div>

		<div class="form_item" id="form">
		<div class="zakaz">Для заказа сладостей заполните форму:</div>
	 	<div class="form"> 
			<form action="send.php" method="post">
				<fieldset class="fieldsets"> 
					<label class="name"> Ваше Имя:
					<input class="name1" type="text" name="fio" placeholder="Укажите ФИО" required>
					</label>
					<label class="mail"> Ваш email:
					<input class="mail1" type="text" name="email" placeholder="Укажите e-mail" required>
					</label>
					<input class="send1" type="submit" value="Отправить">
			</fieldset>
			</form>
		</div> 
		</div>
	</div>
</div>

<!-- Footer -->

<footer class="foot" id="footer">
	<div class="container">
		<div class="footer_inner">
			<div class="footer_logo">Sweetbox@mail.ru</div>
			<div class="footer_inst">
				<a href="https://www.instagram.com/?hl=ru"><img src="assets/images/inst.png"></a>
			</div>
			<div class="footer_vk">
				<a href="https://vk.com/"><img src="assets/images/vk.png"></a>
			</div>
			<div class="footer_number">+7(921)888-95-48</div>
		</div>
		<div class="footer_info">© SweetBOX est. 2019 FFR Group</div>
		
	</div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/slick-carousel@1.8.1/slick/slick.min.js"></script>				
<script src="assets/app.js"></script>

</body>
</html>